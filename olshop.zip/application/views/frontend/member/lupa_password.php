<div class="grid_12">
<?php echo form_open(current_url()); ?>
<label>Email</label> <input type="text" name="email"/> <input type="submit" name="do_request" value="Ok" class="button">
</form>
</div>